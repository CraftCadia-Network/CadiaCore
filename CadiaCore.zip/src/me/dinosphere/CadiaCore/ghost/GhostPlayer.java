package me.dinosphere.CadiaCore.ghost;

public class GhostPlayer {

}